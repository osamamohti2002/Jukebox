<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Jukebox</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="//unpkg.com/alpinejs" defer></script>
</head>
<body class="bg-[#151515] flex flex-col min-h-full">

  <!-- Navbar -->
  <?php if(auth()->guard()->guest()): ?>
      <?php echo $__env->make('layouts.nav-bars.mainNavBar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php endif; ?>


  <?php if(auth()->guard()->check()): ?>
    <?php echo $__env->make('layouts.nav-bars.userNavBar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php endif; ?>


  <main class="flex-grow">
    <?php echo $__env->make('shared._flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>

  </main>

<!-- Footer -->
<footer class="bg-[#111111] text-white text-center py-4">
    <p class="text-sm">© Jukebox 2025</p>
</footer>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\jukebox\resources\views/layouts/app.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="w-[70%] mx-auto mt-10">
  <div class="bg-[#111111] text-white border border-[#04fffb] rounded-lg p-6 shadow-lg">
    <h1 class="text-2xl font-bold mb-4">Genres</h1>
    <?php echo $__env->make('genres._list', ['genres' => $genres], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/genres/show.blade.php ENDPATH**/ ?>
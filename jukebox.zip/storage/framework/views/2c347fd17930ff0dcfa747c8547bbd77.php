<?php if(session('success')): ?>
  <div 
    x-data="{ show: true }" 
    x-show="show" 
    x-init="setTimeout(() => show = false, 5000)" 
    x-transition
    class="mb-4 border border-[#04fffb] text-[#04fffb] rounded px-4 py-2"
  >
    <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>

<?php if(session('error')): ?>
  <div 
    x-data="{ show: true }" 
    x-show="show" 
    x-init="setTimeout(() => show = false, 3000)" 
    x-transition
    class="mb-4 border border-[#04fffb] text-[#04fffb] rounded px-4 py-2"
  >
    <?php echo e(session('error')); ?>

  </div>
<?php endif; ?>

<?php if($errors->any()): ?>
  <div class="mb-4 border border-yellow-400 text-yellow-300 bg-yellow-900/20 rounded px-4 py-2">
    <ul class="list-disc list-inside">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\jukebox\resources\views/shared/_flash.blade.php ENDPATH**/ ?>
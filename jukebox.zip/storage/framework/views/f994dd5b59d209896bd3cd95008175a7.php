<?php $__env->startSection('content'); ?>


<div class="w-[70%] mx-auto mt-10">
  <!-- Genre Selectie -->
  <div class="bg-[#111111] text-white border border-[#04fffb] rounded-lg p-6 shadow-lg">

    <?php echo $__env->make('genres.show', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- Muziek Secties in Grid -->



    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <!-- Liedje 1 -->
      
      


    
      <!-- Voeg meer liedjes toe als je wilt -->
    </div>
  </div>
</div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/index.blade.php ENDPATH**/ ?>
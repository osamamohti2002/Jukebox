  <nav class="bg-[#111111] text-white px-6 py-4 flex justify-between items-center">
    <!-- Titel links -->
    <a href="<?php echo e(route('home')); ?>" class="hover:text-[#04fffb]"><h1 class="text-2xl font-bold border-b-2 border-[#04fffb] inline-block">Juke<span class="text-[#04fffb] hover:text-white">box</span></h1></a>

    <!-- Rechterkant: links -->
    <div class="space-x-4">
      <a href="<?php echo e(route('login')); ?>" class="hover:text-[#04fffb]">Login</a>
      <a href="<?php echo e(route('register')); ?>" class="hover:text-[#04fffb]">Registreren</a>
      <a href="<?php echo e(route('playlist.temp.index')); ?>" class="hover:text-[#04fffb]">Tijdelijke Playlist</a>
    </div>
  </nav><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/layouts/nav-bars/mainNavBar.blade.php ENDPATH**/ ?>
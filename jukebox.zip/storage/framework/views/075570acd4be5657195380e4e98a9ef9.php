<?php $__env->startSection('content'); ?>
<div class="flex min-h-screen bg-[#151515] text-white">
  <!-- Sidebar -->
<aside class="w-1/4 bg-[#111111] p-6 border-r border-[#04fffb]">
  <div class="flex items-center justify-between mb-4">
    <h2 class="text-xl font-bold">Jouw Lijsten</h2>
    <!-- Nieuwe lijst knop -->
    <a href="<?php echo e(route('playlists.create')); ?>" class="bg-[#04fffb] text-black px-3 py-1 text-sm rounded hover:bg-[#03dad8] transition">
      +
    </a>
  </div>

  <ul class="space-y-3">
    <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      $active = isset($playlist) && $playlist->id === $pl->id;
      ?>      
    <li>
      <a
        href="<?php echo e(route('profile', ['playlist' => $pl->id])); ?>"
        class="block px-3 py-2 rounded-lg <?php echo e($active ? 'bg-[#111111] text-[#04fffb]' : 'hover:text-[#04fffb]'); ?>">
        <?php echo e($pl->name); ?>

      </a>

    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </ul>
</aside>


  <!-- Main content -->
  <main class="flex-1 p-8">
    <?php if($playlist): ?>
      <h2 class="text-2xl font-bold mb-4">Playlist: <?php echo e($playlist->name); ?></h2>
    <?php endif; ?>
    <?php if($playlist->songs->isEmpty()): ?>
      <p class="text-gray-400">Nog geen nummers in deze playlist.</p>
    <?php else: ?>
    <?php $__currentLoopData = $playlist->songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $minutes = floor($song->duration / 60);
        $seconds = str_pad($song->duration % 60, 2, '0', STR_PAD_LEFT);
    ?>

      <div class="space-y-4">
        <div class="p-4 bg-[#111111] rounded-lg border border-[#04fffb] flex justify-between items-center">
          <div>
            <h3 class="text-lg font-semibold"><?php echo e($song->song); ?></h3>
            <h6 class="text-lg ">Artist: <?php echo e($song->artiest); ?></h6>
            <p class="text-sm">Duur: <?php echo e($minutes); ?>:<?php echo e($seconds); ?> - Genre: <?php echo e($song->genre); ?></p>
          </div>
          <form action="">
            <button class="text-red-500 hover:text-red-400 font-bold text-lg">×</button>
          </form>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>



</div>

</main>




  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/user/profile.blade.php ENDPATH**/ ?>
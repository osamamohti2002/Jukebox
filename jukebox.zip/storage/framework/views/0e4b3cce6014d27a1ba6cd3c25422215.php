
<?php if($genres->isEmpty()): ?>
  <p class="text-gray-400">Er zijn nog geen genres beschikbaar.</p>
<?php else: ?>
  <ul class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li>
        <a
          href="<?php echo e(route('songs.byGenre', $g->genre)); ?>"
          class="block bg-[#151515] border border-[#04fffb] rounded px-4 py-3 hover:translate-y-[-2px] transition"
        >
          <span class="text-white font-semibold"><?php echo e($g->genre); ?></span>
        </a>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/genres/_list.blade.php ENDPATH**/ ?>
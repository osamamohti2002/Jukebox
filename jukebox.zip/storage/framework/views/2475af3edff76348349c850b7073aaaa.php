<footer class="bg-[#111111] text-white text-center py-4">
    <p class="text-sm">© Jukebox 2025</p>
</footer><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/footer.blade.php ENDPATH**/ ?>
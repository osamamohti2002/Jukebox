<?php $__env->startSection('content'); ?>
<div class="w-[90%] mx-auto mt-10">
  <?php echo $__env->make('shared._flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <div class="bg-[#111111] text-white border border-[#04fffb] rounded-lg p-6 shadow-lg">
    <h1 class="text-2xl font-bold mb-6">Nieuwe playlist maken</h1>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
      
      <div class="md:col-span-1">
        <form action="<?php echo e(route('playlists.store')); ?>" method="POST" class="bg-[#151515] border border-[#04fffb] rounded p-4">
          <?php echo csrf_field(); ?>
          <label class="block mb-2">Naam</label>
          <input type="text" name="name" value="<?php echo e(old('name')); ?>"
                 class="w-full bg-[#111111] text-white border border-[#04fffb] rounded px-3 py-2 mb-3">
          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-400 text-sm mb-3"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

          <button class="w-full px-4 py-2 border border-[#04fffb] rounded">Opslaan</button>
        </form>

        
        <div class="mt-6 bg-[#151515] border border-[#04fffb] rounded p-4">
          <h2 class="font-semibold mb-2">Huidige selectie</h2>
          <p class="text-sm text-gray-300">
            Aantal nummers: <span class="text-white font-semibold"><?php echo e($selectedSongs->count()); ?></span><br>
            Totaal duur:
            <?php
              $total = $selectedSongs->sum('duration');
              $m = floor($total / 60);
              $s = str_pad($total % 60, 2, '0', STR_PAD_LEFT);
            ?>
            <span class="text-white font-semibold"><?php echo e($m); ?>:<?php echo e($s); ?></span>
          </p>
        </div>
      </div>

      
      <div class="md:col-span-1">
        <form action="<?php echo e(route('playlists.create')); ?>" method="GET" class="bg-[#151515] border border-[#04fffb] rounded p-4">
          <label class="block mb-2">Filter op genre</label>
          <select name="genre" class="w-full bg-[#111111] text-white border border-[#04fffb] rounded px-3 py-2 mb-3"
                  onchange="this.form.submit()">
            <option value="">Alle genres</option>
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($g->genre); ?>" <?php echo e($selectedGenre === $g->genre ? 'selected' : ''); ?>>
                <?php echo e($g->genre); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <noscript>
            <button class="w-full px-4 py-2 border border-[#04fffb] rounded">Toepassen</button>
          </noscript>
        </form>
      </div>

      
      <div class="md:col-span-2">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <?php $__empty_1 = true; $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
              $m = floor($song->duration / 60);
              $s = str_pad($song->duration % 60, 2, '0', STR_PAD_LEFT);
              $inDraft = $selectedSongs->contains('id', $song->id);
            ?>

            <div class="bg-[#151515] border border-[#04fffb] rounded p-4 flex justify-between items-start">
              <div>
                <div class="text-lg font-semibold"><?php echo e($song->song); ?></div>
                <div class="text-sm text-gray-300">Duur: <?php echo e($m); ?>:<?php echo e($s); ?> · Genre: <?php echo e($song->genre); ?></div>
              </div>

              <?php if(!$inDraft): ?>
                
                <form action="<?php echo e(route('playlists.create.add', $song)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <button class="text-[#04fffb] text-2xl font-bold hover:scale-110 transition" type="submit">+</button>
                </form>
              <?php else: ?>
                
                <form action="<?php echo e(route('playlists.create.remove', $song)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="text-red-400 text-2xl font-bold hover:scale-110 transition" type="submit">–</button>
                </form>
              <?php endif; ?>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-400">Geen songs gevonden.</p>
          <?php endif; ?>
        </div>

        
        <?php if($selectedSongs->isNotEmpty()): ?>
          <h3 class="text-xl font-semibold mt-6 mb-3">Geselecteerde nummers</h3>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
            <?php $__currentLoopData = $selectedSongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $mm = floor($s->duration / 60);
                $ss = str_pad($s->duration % 60, 2, '0', STR_PAD_LEFT);
              ?>
              <div class="bg-[#151515] border border-[#04fffb] rounded p-3 flex justify-between items-center">
                <div>
                  <div class="font-semibold"><?php echo e($s->song); ?></div>
                  <div class="text-sm text-gray-300">Duur: <?php echo e($mm); ?>:<?php echo e($ss); ?></div>
                </div>
                <form action="<?php echo e(route('playlists.create.remove', $s)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="text-red-400 text-xl font-bold hover:scale-110 transition" type="submit">–</button>
                </form>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/playlist/createPlaylist.blade.php ENDPATH**/ ?>
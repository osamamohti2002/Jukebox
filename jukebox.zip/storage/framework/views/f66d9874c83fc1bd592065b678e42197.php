<?php $__env->startSection('content'); ?>


<div class="w-[70%] mx-auto mt-10">
  <!-- Genre Selectie -->
  <div class="bg-[#111111] text-white border border-[#04fffb] rounded-lg p-6 shadow-lg">
    <h2 class="text-xl font-semibold mb-4">Kies een muziekgenre</h2>
    <form action="<?php echo e(route('home')); ?>">
    <label for="genre" class="block mb-2">Genre:</label>
    <select id="genre" name="genre" name="genre" onchange="this.form.submit()"
      class="w-full bg-[#111111] text-white border border-[#04fffb] rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04fffb] mb-6">
      <option value="">Alle genres</option>
      <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>{

          <option value="<?php echo e($genre->genre); ?>" <?php echo e(request('genre') == $genre->genre ? 'selected' : ''); ?> ><?php echo e($genre->genre); ?></option>
      }
        
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    </form>

    <!-- Muziek Secties in Grid -->



    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <!-- Liedje 1 -->
      
      <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php

        $minutes = floor($song->duration / 60);
        $seconds = str_pad($song->duration % 60, 2, '0', STR_PAD_LEFT);
        ?>
      <div class="bg-[#151515] border border-[#04fffb] rounded p-4 flex flex-col justify-between">
        <a href="/songs/<?php echo e($song->id); ?>">
          <div>
            <h3 class="text-lg font-semibold"><?php echo e($song->song); ?></h3>
            <p class="text-sm text-gray-300">Duur: <?php echo e($minutes); ?>:<?php echo e($seconds); ?>· Genre: <?php echo e($song->genre); ?></p>
          </div>
        </a>
        <form action="<?php echo e(route('playlist.temp.add', $song)); ?>" method="post">
          <?php echo csrf_field(); ?>
        <button class="mt-4 text-[#04fffb] text-2xl font-bold hover:scale-110 transition self-end" type="submit">+</button>
        </form>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    
      <!-- Voeg meer liedjes toe als je wilt -->
    </div>
  </div>
</div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views//index.blade.php ENDPATH**/ ?>
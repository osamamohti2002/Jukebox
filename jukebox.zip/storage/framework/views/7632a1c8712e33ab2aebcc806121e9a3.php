<?php $__env->startSection('content'); ?>
<div class="w-[70%] mx-auto mt-10">
  <div class="bg-[#111111] text-white border border-[#04fffb] rounded-lg p-6 shadow-lg">
    <h1 class="text-2xl font-bold mb-4">Tijdelijke playlist</h1>

    
    <form action="<?php echo e(route('playlist.temp.save')); ?>" method="POST" class="mb-4">
      <?php echo csrf_field(); ?>
      <label class="block mb-2">Naam</label>
      <input type="text" name="name" value="<?php echo e(old('name')); ?>"
             class="w-full bg-[#111111] text-white border border-[#04fffb] rounded px-4 py-2 mb-4">
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-400 text-sm mb-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

      <button class="px-4 py-2 border border-[#04fffb] rounded">Opslaan</button>
    </form>

    <?php if($songs->isEmpty()): ?>
      <p class="text-gray-400">Je tijdelijke playlist is leeg of verlopen.</p>
      <a href="<?php echo e(route('home')); ?>" class="inline-block mt-4 underline">Terug naar home</a>
    <?php else: ?>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $minutes = floor($song->duration / 60);
            $seconds = str_pad($song->duration % 60, 2, '0', STR_PAD_LEFT);
          ?>

          <div class="bg-[#151515] border border-[#04fffb] rounded p-4 flex flex-col justify-between">
            <div>
              <h3 class="text-lg font-semibold"><?php echo e($song->song); ?></h3>
              <p class="text-sm text-gray-300">
                Duur: <?php echo e($minutes); ?>:<?php echo e($seconds); ?> · Genre: <?php echo e($song->genre); ?>

              </p>
            </div>

            
            <form action="<?php echo e(route('playlist.temp.remove', $song)); ?>" method="POST" class="mt-4 self-end">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button class="text-red-400 hover:scale-110 transition" type="submit">Verwijderen</button>
            </form>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <?php
        $totMin = floor($totalSeconds / 60);
        $totSec = str_pad($totalSeconds % 60, 2, '0', STR_PAD_LEFT);
      ?>
      <div class="mt-2 text-sm text-gray-300">
        Totale duur: <span class="text-white font-semibold"><?php echo e($totMin); ?>:<?php echo e($totSec); ?></span>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/playlist/temporaryPlaylist.blade.php ENDPATH**/ ?>



<?php $__env->startSection('content'); ?>


<div class="w-[70%] mx-auto mt-10">
    <div class="bg-[#111111] text-white border border-[#04fffb] rounded-lg p-6 shadow-lg">

<h1 class="text-xl font-semibold mb-4">Jouw Playlists</h1>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">

  <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="bg-[#151515] border border-[#04fffb] rounded p-4 flex flex-col justify-between">
          <div class="flex items-center justify-between mb-4">
        <a href="<?php echo e(route('playlists.show', $playlist)); ?>"><h2 class="text-lg font-semibold"><?php echo e($playlist->name); ?></h2></a>

        <form action="">
            <button class="text-red-500 hover:text-red-400 font-bold text-lg">×</button>
        </form>
          </div>
      </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    </div>
</div>




<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/playlist/index.blade.php ENDPATH**/ ?>
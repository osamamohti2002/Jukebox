<?php $__env->startSection('content'); ?>

    <div class="flex items-center justify-center min-h-screen bg-[#151515]">
  <div class="bg-[#111111] text-white p-8 rounded-lg shadow-lg w-full max-w-sm border border-[#04fffb]">
    <h2 class="text-2xl font-bold mb-6 text-center">Registreren</h2>

    <!-- Naam -->
    <div class="mb-4">
      <label for="name" class="block mb-2">Naam</label>
      <input
        type="text"
        id="name"
        name="name"
        class="w-full px-4 py-2 rounded bg-[#151515] border border-[#04fffb] text-white focus:outline-none focus:ring-2 focus:ring-[#04fffb]"
        placeholder="Jouw naam"
        required
      />
    </div>

    <!-- E-mail -->
    <div class="mb-4">
      <label for="email" class="block mb-2">E-mailadres</label>
      <input
        type="email"
        id="email"
        name="email"
        class="w-full px-4 py-2 rounded bg-[#151515] border border-[#04fffb] text-white focus:outline-none focus:ring-2 focus:ring-[#04fffb]"
        placeholder="jij@example.com"
        required
      />
    </div>

    <!-- Wachtwoord -->
    <div class="mb-6">
      <label for="password" class="block mb-2">Wachtwoord</label>
      <input
        type="password"
        id="password"
        name="password"
        class="w-full px-4 py-2 rounded bg-[#151515] border border-[#04fffb] text-white focus:outline-none focus:ring-2 focus:ring-[#04fffb]"
        placeholder="••••••••"
        required
      />
    </div>

    <!-- Registreren knop -->
    <button
      type="submit"
      class="w-full bg-[#04fffb] text-black font-semibold py-2 rounded hover:bg-[#03dad8] transition"
    >
      Registreren
    </button>
  </div>
</div>


  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/registreer.blade.php ENDPATH**/ ?>
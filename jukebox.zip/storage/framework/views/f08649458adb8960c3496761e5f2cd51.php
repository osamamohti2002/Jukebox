


<?php $__env->startSection('content'); ?>


<div class="w-[70%] mx-auto mt-10">
    <div class="bg-[#111111] text-white border border-[#04fffb] rounded-lg p-6 shadow-lg">

<h1 class="text-xl font-semibold mb-4">Playlist: <?php echo e($playlist->name); ?></h1>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">

  <?php $__currentLoopData = $playlist->songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="bg-[#151515] border border-[#04fffb] rounded p-4 flex flex-col justify-between">
        <h2 class="text-lg font-semibold"><?php echo e($song->song); ?></h2>
        <h6 class="text-lg ">Artist: <?php echo e($song->artiest); ?></h6>
        <p class="text-sm text-gray-300">Min: <?php echo e(floor($song->duration/60)); ?>:<?php echo e(str_pad($song->duration%60,2,'0',STR_PAD_LEFT)); ?></p>
        <p class="text-sm text-gray-300">Genre: <?php echo e($song->genre); ?></p>

        <form action="">
            <button class="text-red-500 hover:text-red-400 font-bold text-lg">×</button>
        </form>
      </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    </div>
</div>




<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/playlist/show.blade.php ENDPATH**/ ?>
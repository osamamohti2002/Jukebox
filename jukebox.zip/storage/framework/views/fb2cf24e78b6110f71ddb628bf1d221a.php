<nav class="bg-[#111111] text-white px-6 py-4 flex justify-between items-center">

  <!-- Titel links -->
  <a href="<?php echo e(route('home')); ?>" class="hover:text-[#04fffb]">
    <h1 class="text-2xl font-bold border-b-2 border-[#04fffb] inline-block">
      Juke<span class="text-[#04fffb] hover:text-white">box</span>
    </h1>
  </a>

  <!-- Rechterkant: profiel + logout -->
  <div class="flex items-center space-x-4">
    <a href="<?php echo e(route('profile')); ?>" class="hover:text-[#04fffb]">Profiel</a>
    <a href="<?php echo e(route('playlists.index', $playlist)); ?>" class="hover:text-[#04fffb]">Playlists</a>
    <form action="<?php echo e(route('logout')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <button type="submit" class="hover:text-[#04fffb]">Log uit</button>
    </form>
  </div>
</nav>
<?php /**PATH C:\xampp\htdocs\jukebox\resources\views/layouts/nav-bars/userNavBar.blade.php ENDPATH**/ ?>